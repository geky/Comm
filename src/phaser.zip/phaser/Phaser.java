package phaser;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Graphics;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Mixer;
import javax.swing.JFrame;
import javax.swing.JLabel;


public class Phaser extends JFrame implements Runnable {
		
	
	public static final byte HEADER = 0x48;
	public static final byte JOIN_BYTE = 0x49;
	public static final byte EVENT_BYTE = 0x4c;
	public static final byte PING_BYTE = 0x0;
	
	public static final int PORT = 35721;
	public static final int BUFFER_SIZE = 256;
	public static final int HEADER_SIZE = 11;
	
	public static void main(String[] args) {
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
	        public void run() {
	            Phaser me = new Phaser();
	            me.run();
	        }
	    });
	}
	
	
	public static DatagramSocket socket;
	public static Map<InetAddress,Connection> activePeers;
	public static Map<InetAddress,Connection> lostPeers;
	
	public static int eventMask;
	public static byte[][] events; 
	public static int[] eventTimes;
	public static int nextEvent;
	public static long maskResetTime;
	
	public static long timeStart;
	public static int time;
	
	public Phaser() {
		super("Phaser");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(new Dimension(640,400));
        
        activePeers = new HashMap<InetAddress,Connection>();
        lostPeers = new HashMap<InetAddress,Connection>();
        
        maskResetTime = timeStart = System.currentTimeMillis();
        
        eventMask = 0;
        nextEvent = 0;
        events = new byte[32][];
        eventTimes = new int[32];
        
        try {
			socket = new DatagramSocket(PORT);
		} catch (SocketException e) {
			e.printStackTrace();
			System.exit(1);
		}
        
        setVisible(true);
	}
	
	public static void updateTime() {
		time = (int)(System.currentTimeMillis() - timeStart);
	}
	
	public static ByteBuffer makeEventBuffer() {
		ByteBuffer b = ByteBuffer.allocate(BUFFER_SIZE-HEADER_SIZE);
		b.position(6);
		return b;
	}
	
	public static void setEvent(ByteBuffer event) {
		event.put((byte)nextEvent);
		event.putInt(time);
		event.put((byte)(event.limit() - 6));
		
		eventMask ^= 0x1 << nextEvent;
		events[nextEvent] = event.array();
		send(makeBuffer().put(EVENT_BYTE).put(events[nextEvent++]));
		nextEvent = ++nextEvent % 32;
	}
	
	public static int collideEvents(int bit, int mask, int time) {
		if (((0x1 << bit) & (mask ^ eventMask)) != 0) {
			System.out.println("switch 0");
			return bit;
		} else if (time > eventTimes[bit]) {
			System.out.println("switch 1");
			return collideEvents((bit+1) % 32,mask^((bit+1) % 32),time);
		} else if (time < eventTimes[bit]) {
			System.out.println("switch 2");
			int moveTo = collideEvents((bit+1) % 32,eventMask^((bit+1) % 32),eventTimes[bit]);
			eventTimes[moveTo] = eventTimes[bit];
			events[moveTo] = events[bit];
			return bit;
		} else {
			System.out.println("switch 3");
			return -1;
		}
	}
	
	public static ByteBuffer makeBuffer() {
		ByteBuffer b = ByteBuffer.allocate(BUFFER_SIZE);
		b.put(HEADER);
		b.putInt(eventMask);
		b.putInt(time);
		return b;
	}
	
	public static void send(ByteBuffer b) {
		DatagramPacket dp = new DatagramPacket(b.array(),BUFFER_SIZE,null,PORT);
		for (Connection c : activePeers.values()) {
			dp.setAddress(c.address);
			try {
				socket.send(dp);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	public static void send(ByteBuffer b,Connection dest) {
		DatagramPacket dp = new DatagramPacket(b.array(),BUFFER_SIZE,dest.address,PORT);
		try {
			socket.send(dp);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void run() {
		while (true) {			
			ByteBuffer buffer = ByteBuffer.allocate(BUFFER_SIZE);
			DatagramPacket packet = new DatagramPacket(buffer.array(), BUFFER_SIZE);
	        try {
				socket.receive(packet);
			} catch (IOException e) {
				e.printStackTrace();
				continue;
			}
	        
	        if (buffer.get() != HEADER)
	        	continue;
	        
	        
	        Connection peer;
	        if (lostPeers.containsKey(packet.getAddress())) {
	        	peer = lostPeers.remove(packet.getAddress());
	        	activePeers.put(packet.getAddress(), peer);
	        } else {
	        	peer = activePeers.get(packet.getAddress());
	        }
	        
	        int maskSent = buffer.getInt();
        	int timeSent = buffer.getInt();
        	byte intent = buffer.get();
        	
        	if (intent != JOIN_BYTE && intent != EVENT_BYTE && timeSent+timeStart > maskResetTime) {
	        	maskSent ^= eventMask;
	        	if (maskSent != 0) {
	        		for (int t=0; t<32; t++) {
	        			if (((maskSent >>> t) & 0x1) != 0) {
	        				ByteBuffer e = makeBuffer();
	        				e.put(EVENT_BYTE).putInt(eventTimes[t]);
	        				e.put((byte)events[t].length).put(events[t]);
	        				send(e,peer);
	        			}
	        		}
	        	}
	        }
        	
	        
	        switch (intent) {
	        	case JOIN_BYTE: { 
		        	long senderTimeStart = buffer.getLong();
		        		
		        	if (senderTimeStart == timeStart && maskSent == eventMask) {
						activePeers.put(packet.getAddress(), new Connection(packet.getAddress()));
		        	} else {
		        		if (senderTimeStart < timeStart) {
			        		eventMask = maskSent;
			        		maskResetTime = time+timeStart;
			        		timeStart = senderTimeStart;
		        		}
		        		
		        		ByteBuffer reply = makeBuffer();
		        		reply.putLong(timeStart);
		        		reply.put((byte)(activePeers.size() + lostPeers.size()));
		        		for (InetAddress p:activePeers.keySet()) {
		        			reply.put(p.getAddress());
		        		}
		        		for (InetAddress p:lostPeers.keySet()) {
		        			reply.put(p.getAddress());
		        		}
		        		reply.flip();
		        		
		        		send(reply,peer);
		        	}
	        	} continue;
	        	
	        	case EVENT_BYTE: {	        		
	        		byte bit = buffer.get();
	        		int eventTime = buffer.getInt();
	        		
	        		if (eventTime+timeStart > maskResetTime)  {
	        			
	        			if (((0x1 << bit) & (maskSent ^ eventMask)) == 0 && eventTimes[bit] == eventTime)
	        				continue;
	        			
	        			bit = (byte)collideEvents(bit,maskSent,eventTime);
	        			if (bit == -1)
	        				continue;
	        			
	        			byte size = buffer.get();
	        			ByteBuffer event = ByteBuffer.allocate(size + 6);
	        			event.put(bit);
	        			event.putInt(eventTime);
	        			event.put(size);
	        			event.put(buffer.array(),buffer.position(),size);
	        			
	        			if (peer != null) {
	        				//TODO execute the event
	        			}
	        			
	        			events[bit] = event.array();
	        			eventMask ^= 0x1 << bit;
	        			nextEvent = (bit+1) % 32;
	        		}
	        	} continue;
	        
	        	case PING_BYTE: {
	        		if (peer != null)
	        			peer.pingTime = time;
	        	} continue;
	        }
		}
	}
	
	public void paint(Graphics g) {
		super.paint(g);
	}
}
