package phaser;

import java.net.DatagramPacket;
import java.nio.ByteBuffer;
import java.util.Iterator;

public class User extends Thread{
	public static final int TIME_OUT = 5000;
	public static final int TIME_PING = 1000;
	public static final int TIME_SOUND = 100;
	
	private boolean soundOn = false;
	
	@Override
	public void run() {
		while (true) {
			
			Iterator<Connection> peers = Phaser.activePeers.values().iterator();
			while (peers.hasNext()) {
				Connection p = peers.next();
				if (p.pingTime > TIME_OUT) {
					Phaser.lostPeers.put(p.address, p);
					peers.remove();
				}
			}
			
			ByteBuffer packet = Phaser.makeBuffer();
			packet.put(Phaser.PING_BYTE);
			packet.flip();
			Phaser.send(packet);
			
			try {
				wait(soundOn ? TIME_SOUND : TIME_PING);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
