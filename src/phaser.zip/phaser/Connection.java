package phaser;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;

public class Connection {
	
	
	
	public String name;
	public InetAddress address;
	public int pingTime;
	
	public Connection(InetAddress ip) {
		address = ip;
		name = ip.toString();
	}
	
	public Connection(InetAddress ip, String name) {
		this(ip);
		this.name = name;
	}
	
	public void update(byte[] b) {
		
	}
}
